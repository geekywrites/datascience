## 500 + 𝗔𝗿𝘁𝗶𝗳𝗶𝗰𝗶𝗮𝗹 𝗜𝗻𝘁𝗲𝗹𝗹𝗶𝗴𝗲𝗻𝗰𝗲 𝗣𝗿𝗼𝗷𝗲𝗰𝘁 𝗟𝗶𝘀𝘁 𝘄𝗶𝘁𝗵 𝗰𝗼𝗱𝗲

*500 AI Machine learning Deep learning Computer vision NLP Projects with code*

***This list is continuously updated.*** - You can take pull request and contribute.

| Sr No | Name                                                         | Link                                |
| ----- | ------------------------------------------------------------ | ----------------------------------- |
| 1     | 180 Machine learning Project                                 | [is.gd/MLtyGk](http://is.gd/MLtyGk) |
| 2     | 12 Machine learning Object Detection                         | [is.gd/jZMP1A](http://is.gd/jZMP1A) |
| 3     | 20 NLP Project with Python                                   | [is.gd/jcMvjB](http://is.gd/jcMvjB) |
| 4     | 10 Machine Learning Projects on Time Series Forecasting      | [is.gd/dOR66m](http://is.gd/dOR66m) |
| 5     | 20 Deep Learning Projects Solved and Explained with Python   | [is.gd/8Cv5EP](http://is.gd/8Cv5EP) |
| 6     | 20 Machine learning Project                                  | [is.gd/LZTF0J](http://is.gd/LZTF0J) |
| 7     | 30 Python Project Solved and Explained                       | [is.gd/xhT36v](http://is.gd/xhT36v) |
| 8     | Machine learning Course for Free                             | https://lnkd.in/ekCY8xw             |
| 9     | 5 Web Scraping Projects with Python                          | [is.gd/6XOTSn](http://is.gd/6XOTSn) |
| 10    | 20 Machine Learning Projects on Future Prediction with Python | [is.gd/xDKDkl](http://is.gd/xDKDkl) |
| 11    | 4 Chatbot Project With Python                                | [is.gd/LyZfXv](http://is.gd/LyZfXv) |
| 12    | 7 Python Gui project                                         | [is.gd/0KPBvP](http://is.gd/0KPBvP) |
| 13    | All Unsupervised learning Projects                           | [is.gd/cz11Kv](http://is.gd/cz11Kv) |
| 14    | 10 Machine learning Projects for Regression Analysis         | [is.gd/k8faV1](http://is.gd/k8faV1) |
| 15    | 10 Machine learning Project for Classification with Python   | [is.gd/BJQjMN](http://is.gd/BJQjMN) |
| 16    | 6 Sentimental Analysis Projects with python                  | [is.gd/WeiE5p](http://is.gd/WeiE5p) |
| 17    | 4 Recommendations Projects with Python                       | [is.gd/pPHAP8](http://is.gd/pPHAP8) |
| 18    | 20 Deep learning Project with python                         | [is.gd/l3OCJs](http://is.gd/l3OCJs) |
| 19    | 5 COVID19 Projects with Python                               | [is.gd/xFCnYi](http://is.gd/xFCnYi) |
| 20    | 9 Computer Vision Project with python                        | [is.gd/lrNybj](http://is.gd/lrNybj) |
| 21    | 8 Neural Network Project with python                         | [is.gd/FCyOOf](is.gd/FCyOOf)        |
| 22    | 5 Machine learning Project for healthcare                    | https://bit.ly/3b86bOH              |
| 23    | 5 NLP Project with Python                                    | https://bit.ly/3hExtNS              |
| 24    | 47 Machine Learning Projects for 2021                        | https://bit.ly/356bjiC              |
| 25    | 19 Artificial Intelligence Projects for 2021                 | https://bit.ly/38aLgsg              |
| 26    | 28 Machine learning Projects for 2021                        | https://bit.ly/3bguRF1              |
| 27    | 16 Data Science Projects with Source Code for 2021           | https://bit.ly/3oa4zYD              |
| 28    | 24 Deep learning Projects with Source Code for 2021          | https://bit.ly/3rQrOsU              |
| 29    | 25 Computer Vision Projects with Source Code for 2021        | https://bit.ly/2JDMO4I              |
| 30    | 23 Iot Projects with Source Code for 2021                    | https://bit.ly/354gT53              |
| 31    | 27 Django Projects with Source Code for 2021                 | https://bit.ly/2LdRPRZ              |
| 32    | 37 Python Fun Projects with Code for 2021                    | https://bit.ly/3hBHzz4              |
| 33    | 500 + Top Deep learning Codes                                | https://bit.ly/3n7AkAc              |
| 34    | 500 + Machine learning Codes                                 | https://bit.ly/3b32n13              |
| 35    | 20+ Machine Learning Datasets & Project Ideas                | https://bit.ly/3b2J48c              |
| 36    | 1000+ Computer vision codes                                  | https://bit.ly/2LiX1nv              |
| 37    | 300 + Industry wise Real world projects with code            | https://bit.ly/3rN7lVR              |
| 38    | 1000 + Python Project Codes                                  | https://bit.ly/3oca2xM              |
| 39    | 363 + NLP Project with Code                                  | https://bit.ly/3b442DO              |
| 40    | 50 + Code ML Models (For iOS 11) Projects                    | https://bit.ly/389dB2s              |
| 41    | 180 + Pretrained Model Projects for Image, text, Audio and Video | https://bit.ly/3hFyQMw              |
| 42    | 50 + Graph Classification Project List                       | https://bit.ly/3rOYFhH              |
| 43    | 100 + Sentence Embedding(NLP Resources)                      | https://bit.ly/355aS8c              |
| 44    | 100 + Production Machine learning Projects                   | https://bit.ly/353ckI0              |
| 45    | 300 + Machine Learning Resources Collection                  | https://bit.ly/3b2LjIE              |
| 46    | 70 + Awesome AI                                              | https://bit.ly/3hDIXkD              |
| 47    | 150 + Machine learning Project Ideas with code               | https://bit.ly/38bfpbg              |
| 48    | 100 + AutoML Projects with code                              | https://bit.ly/356zxZX              |
| 49    | 100 + Machine Learning Model Interpretability Code Frameworks | https://bit.ly/3n7FaNB              |
| 50    | 120 + Multi Model Machine learning Code Projects             | https://bit.ly/38QRI76              |
| 51    | Awesome Chatbot Projects                                     | https://bit.ly/3rQyxmE              |
| 52    | Awesome ML Demo Project with iOS                             | https://bit.ly/389hZOY              |
| 53    | 100 + Python based Machine learning Application Projects     | https://bit.ly/3n9zLWv              |
| 54    | 100 + Reproducible Research Projects of ML and DL            | https://bit.ly/2KQ0J8C              |
| 55    | 25 + Python Projects                                         | https://bit.ly/353fRpK              |
| 56    | 8 + OpenCV Projects                                          | https://bit.ly/389mj0B              |
| 57    | 1000 + Awesome Deep learning Collection                      | https://bit.ly/3b0a9Jj              |
| 58    | 200 + Awesome NLP learning Collection                        | https://bit.ly/3b74b9o              |
| 59    | 200 + The Super Duper NLP Repo                               | https://bit.ly/3hDNnbd              |
| 60    | 100 + NLP dataset for your Projects                          | https://bit.ly/353h2Wc              |
| 61    | 364 + Machine Learning Projects definition                   | https://bit.ly/2X5QRdb              |
| 62    | 300+ Google Earth Engine Jupyter Notebooks to Analyze Geospatial Data | https://bit.ly/387JwjC              |
| 63    | 1000 + Machine learning Projects Information                 | https://bit.ly/3rMGk4N              |
| 64.   | 11 Computer Vision Projects with code                        | https://bit.ly/38gz2OR              |
| 65.   | 13 Computer Vision Projects with Code                        | https://bit.ly/3hMJdhh              |
| 66.   | 13 Cool Computer Vision GitHub Projects To Inspire You       | https://bit.ly/2LrSv6d              |
| 67.   | Open-Source Computer Vision Projects (With Tutorials)        | https://bit.ly/3pUss6U              |
| 68.   | OpenCV Computer Vision Projects with Python                  | https://bit.ly/38jmGpn              |
| 69.   | 100 + Computer vision Algorithm Implementation               | https://bit.ly/3rWgrzF              |
| 70.   | 80 + Computer vision Learning code                           | https://bit.ly/3hKCpkm              |
| 71.   | Deep learning Treasure                                       | https://bit.ly/359zLQb              |

